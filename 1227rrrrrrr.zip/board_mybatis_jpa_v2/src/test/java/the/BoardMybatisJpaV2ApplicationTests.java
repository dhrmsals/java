package the;

import java.util.List;
import java.util.Vector;
import java.util.stream.IntStream;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.stereotype.Repository;

import the.domain.dto.myBoard.MyBoardDto;
import the.domain.entity.Board;
import the.domain.entity.BoardRepository;
import the.domain.entity.multifile.MultiFileBoardEntity;
import the.domain.entity.multifile.MultiFileBoardEntityRepository;
import the.domain.entity.multifile.MultiFileEntity;
import the.domain.entity.multifile.MultiFileEntityRepository;
import the.mapper.MyBoardMapper;

@SpringBootTest
class BoardMybatisJpaV2ApplicationTests {

	@Autowired
	MyBoardMapper boardMapper;
	
	@Autowired
	BoardRepository reopsitory;
	
	@Autowired
	MultiFileBoardEntityRepository mreopsitory;
	
	@Transactional
	@Test
	void 멀티1파일게시판읽어오기(){
		List<MultiFileBoardEntity> list=mreopsitory.findAll();
	
	}
	
	//@Test 
	void 멀티파일게시판데이터삽입(){
		MultiFileEntity fent=MultiFileEntity.builder()
				.filePath("/tt/").fileOrgName("dd").fileNewName("dd").fileSize(10)
				.build();
		MultiFileEntity fent2=MultiFileEntity.builder()
				.filePath("/tt/").fileOrgName("dd").fileNewName("dd").fileSize(10)
				.build();
		List<MultiFileEntity> files=new Vector<>();
		files.add(fent);
		files.add(fent2);
		
		MultiFileBoardEntity entity=MultiFileBoardEntity.builder()
				.subject("제목테스트").content("ss").writer("kk").files(files)
				.build();
		mreopsitory.save(entity);
	}
	
	//@Test
	void jpa게시판데이터삽입() {
		IntStream.rangeClosed(1, 100000).forEach(i->{
			Board entity=Board.builder()
					.subject("제목테스트 "+i).content("내용테스트 "+i).writer("작성자"+(i%10+1))
					.build();
			reopsitory.save(entity);
		});
		
	}
	
	//@Test
	void 데이터읽어오기() {
		MyBoardDto myBoardDto=boardMapper.find(1L);
		System.out.println(myBoardDto);
	}
	
	//@Test
	void 더미데이터입력() {
		IntStream.rangeClosed(21, 100000).forEach(i->{
			MyBoardDto myBoardDto=MyBoardDto.builder()
					.subject("제목테스트 "+i).content("내용테스트 "+i).writer("노원그린")
					.build();
			boardMapper.save(myBoardDto);
		});
		
	}

}
