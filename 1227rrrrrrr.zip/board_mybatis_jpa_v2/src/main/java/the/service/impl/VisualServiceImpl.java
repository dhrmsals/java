package the.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import lombok.RequiredArgsConstructor;
import the.domain.dto.visual.VisualFileListDto;
import the.domain.dto.visual.VisualSaveDto;
import the.domain.entity.Visual;
import the.domain.entity.VisualFile;
import the.domain.entity.VisualFileRepository;
import the.service.VisualService;
import the.util.FileUtils;

@RequiredArgsConstructor
@Service
public class VisualServiceImpl implements VisualService {
	
	
	final VisualFileRepository repository;
	
	@Override
	public String tempFileUpload(MultipartFile file) {
		String tempPath="/images/visual/temp/";
		
		FileUtils.tempImgUpload(file, tempPath);
		
		return tempPath+file.getOriginalFilename(); //"/images/visual/temp/"+파일이름
	}

	@Override
	public String moveAndSave(MultipartFile file, VisualSaveDto dto) {
		String destPath="/images/visual/";
		FileUtils.moveTempToDest(destPath);
		
		//DB에저장?????
		VisualFile entity=VisualFile.builder()
				.fileName(file.getOriginalFilename())
				.filePath(destPath)
				.fileSize(file.getSize())
				.visual(dto.toEntity()) //Visual entity객체...
				.build();
		repository.save(entity);
		
		
		return "visual/write";
	}

	@Override
	public String getList(Model model) {
		//ModelAndView mv=new ModelAndView("visual/img-list");
		/*
		List<VisualFile> result=repository.findAll();
		for(VisualFile vf:result) {
			System.out.println("파일이름: " +vf.getFileName());
			System.out.println("파일패스: " +vf.getFilePath());
			System.out.println("파일크기: " +vf.getFileSize());
			Visual v=vf.getVisual();
			System.out.println("타이틀: "+ v.getTitle());
			System.out.println("서브타이틀: "+ v.getSub());
			System.out.println("--------------------");
		}
		*/
		/*
		//entity를 dto클래스로 매핑후 페이지로 데이터 전송
		List<VisualFileListDto> result=repository.findAll().stream()
				.map(VisualFileListDto::new)
				.collect(Collectors.toList());
		model.addAttribute("list", result);
		*/
		
		model.addAttribute("list", repository.findAll());
		
		return "visual/img-list";
	}

	@Override
	public String getVisualList(Model model) {
		model.addAttribute("list", repository.findAll());
		return "common/visual-list";
	}

	

}