package the.service.impl;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;

import lombok.RequiredArgsConstructor;
import the.domain.dto.file.GoodsFileDto;
import the.domain.dto.goods.Goods;
import the.mapper.GoodsFileMapper;
import the.mapper.GoodsMapper;
import the.service.GoodsService;
import the.util.FileUtils;

@RequiredArgsConstructor
@Service
public class GoodsServiceImpl implements GoodsService {

	final GoodsMapper goodsMapper;
	final GoodsFileMapper goodsFileMapper;
	
	@Override
	public String saveAndImgUpload(Goods dto, MultipartFile file) {
		//1.상품정보저장
		goodsMapper.save(dto);// 상품정보
		//pk값은 dto.no 저장된상태
		
		//2.이미지정보저장,upload
		String fileName=file.getOriginalFilename();
		String fileURI="/images/goods/";
		long fileSize=file.getSize();
		GoodsFileDto goodsFileDto=GoodsFileDto.builder()
				.fileName(fileName).fileURI(fileURI).fileSize(fileSize)
				.gno(dto.getNo())//FK 넣어서 입력
				.build();
		goodsFileMapper.save(goodsFileDto);//상품이미지저장
		
		ClassPathResource cpr=new ClassPathResource("static"+fileURI);
		try {
			file.transferTo(new File(cpr.getFile() , fileName));
			System.out.println("bin");
			
			//String testPath="images/goods/";
			//file.transferTo(new File(testPath+fileName));
			//System.out.println("src");			
			System.out.println("파일업로드완료!");
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return "redirect:/goods";
	}

	@Override
	public String getList(Model model) {
		/*
		//목록정보
		List<Goods> goodsList=goodsMapper.findAll();
		//여기까지는 파일이 셋팅않된상태
		
		List<Goods> goodsDto=new Vector<>();
		//파일정보
		for(Goods goods:goodsList) {
			//pk값을 이용해서 파일 읽어 옵시다.
			GoodsFileDto img=goodsFileMapper.getImgInfo(goods.getNo());
			goods.setImg(img);
			goodsDto.add(goods);
		}
		*/
		List<Goods> goodsList=goodsMapper.findAll().stream()
				.map(goods->{
					//이미지데이터 셋팅
					GoodsFileDto img=goodsFileMapper.getImgInfo(goods.getNo());
					goods.setImg(img);
					
					//이미지데이터가 셋팅된 Goods객체 리턴
					return goods;
				})
				.collect(Collectors.toList());
		
		model.addAttribute("list", goodsList);
		
		return "goods/list";
	}

	//파일버튼눌렀을때 서버의 temp경로에 임시 업로드
	@Override
	public String tempImgUpload(MultipartFile fileImg) {
		String path="/images/goods/temp/";
		return FileUtils.tempImgUpload(fileImg, path); 
	}

	@Override
	public String saveAndImgTempToLoc(Goods dto, MultipartFile file) {
		//DB에정보저장	
		goodsMapper.save(dto); //selectKey에의해 no값이 dto에 저장된다.
		//System.out.println("pk값(no컬럼) : " + dto.getNo());
		long fileSize=file.getSize();
		String fileName=file.getOriginalFilename();
		String path="/images/goods/"; //path+fileName 이미지 경로가 되도록 설정
		
		GoodsFileDto goodsFileDto=GoodsFileDto.builder()
				.fileSize(fileSize).fileName(fileName).fileURI(path)
				.gno(dto.getNo())//fk 설정
				.build();
		goodsFileMapper.save(goodsFileDto);
		
		//파일이동(temp-> goods)
		FileUtils.moveTempToDest(path);
		
		return "redirect:/goods";
	}

}
