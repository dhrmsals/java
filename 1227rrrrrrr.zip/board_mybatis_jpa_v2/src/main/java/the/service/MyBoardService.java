package the.service;

import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;

import the.domain.dto.myBoard.MyBoardDto;

public interface MyBoardService {


	String getList(Model model, int page);

	String saveAndFileUpload(MyBoardDto dto, MultipartFile file) throws Exception, Throwable ;

}
