package the.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import lombok.RequiredArgsConstructor;
import the.domain.dto.multifile.MultiFileBoardDto;
import the.domain.dto.multifile.MultiFileUpdateDto;
import the.service.MultiFileBoardService;

@RequiredArgsConstructor
@Controller
public class MultiFileBoardController {
	
	final MultiFileBoardService service;
	
	@GetMapping("/multifiles")// ?page=1
	public String list(Model model, @RequestParam(defaultValue = "1") int page) {
		return service.getList(model, page);
	}
	@GetMapping("/multifiles/write")
	public String writePage() {
		return "multifile/write";
	}
	
	// MultipartHttpServletRequest req
	@PostMapping("/multifiles")
	public String save(MultiFileBoardDto dto) {
				
		return service.fileUploadAndSave(dto);
		//return service.fileUploadAndSave(dto, req);
	}
	
	@GetMapping("/multifiles/{bno}")
	public String detail(@PathVariable long bno ,Model model) {
		return service.getDeateil(bno, model);
	}
	
	@GetMapping("/multifiles/download")//?fno=${f.fno}, bno=${detail.bno}
	public void fileDownload(long fno, long bno,HttpServletResponse response) {
		service.fileDownload(fno, bno,response);
	}
	@GetMapping("/multifiles/{bno}/files/{fno}")
	public String fileDelete(@PathVariable long fno,@PathVariable long bno){
		return service.fileDelete(fno, bno);
		
	}
	@PutMapping("/multifiles/{bno}")
	public String update(@PathVariable long bno,MultiFileUpdateDto dto) {
		System.out.println("put메핑이처리됩니다.");
		
		return service.update(bno,dto);
		
	}
}
