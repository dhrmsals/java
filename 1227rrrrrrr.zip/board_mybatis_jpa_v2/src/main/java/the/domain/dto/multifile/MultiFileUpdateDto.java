package the.domain.dto.multifile;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class MultiFileUpdateDto {
	
	private String subject;
	private String content;
	
	MultipartFile addfile;
	
	
}
