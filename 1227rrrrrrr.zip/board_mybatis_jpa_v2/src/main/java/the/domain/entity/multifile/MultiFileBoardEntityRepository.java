package the.domain.entity.multifile;

import org.apache.ibatis.annotations.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

@Repository //dao역할                 								//참고할테이블이름			//pk값	
public interface MultiFileBoardEntityRepository  extends JpaRepository<MultiFileBoardEntity, Long>{
	//사용자가만들 쿼리영역
	
	@Modifying//dml(insder,update,delete)
	@Query("delete from MultiFileEntity f where f.fno=?1")
	int deleteFile(long fno);
	
	
}
