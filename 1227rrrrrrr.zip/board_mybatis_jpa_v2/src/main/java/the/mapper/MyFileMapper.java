package the.mapper;

import org.apache.ibatis.annotations.Mapper;

import the.domain.dto.file.FileDto;

@Mapper
public interface MyFileMapper {

	void save(FileDto fileDto);

}
