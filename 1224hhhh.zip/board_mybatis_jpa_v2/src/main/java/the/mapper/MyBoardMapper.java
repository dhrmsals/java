package the.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.session.RowBounds;

import the.domain.dto.myBoard.MyBoardDto;

@Mapper
public interface MyBoardMapper {

	void save(MyBoardDto myBoardDto);

	MyBoardDto find(long no);

	List<MyBoardDto> pageList(RowBounds rowBounds);

	int getRowsTotal();

}
