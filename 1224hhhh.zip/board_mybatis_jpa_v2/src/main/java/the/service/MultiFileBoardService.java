package the.service;

import the.domain.dto.multifile.MultiFileBoardDto;

public interface MultiFileBoardService {

	String fileUploadAndSave(MultiFileBoardDto dto);

}
