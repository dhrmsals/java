package the.service.impl;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Vector;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import the.domain.dto.multifile.MultiFileBoardDto;
import the.domain.entity.multifile.MultiFileBoardEntity;
import the.domain.entity.multifile.MultiFileBoardEntityRepository;
import the.domain.entity.multifile.MultiFileEntity;
import the.service.MultiFileBoardService;

@Service
public class MultiFileBoardServiceImpl implements MultiFileBoardService {
	
	@Autowired
	private MultiFileBoardEntityRepository repository; 
	
	@Override
	public String fileUploadAndSave(MultiFileBoardDto dto) {
		
		List<MultiFileEntity> files=fileUpload(dto.getFiles());
		
		MultiFileBoardEntity entity=MultiFileBoardEntity.builder()
				.subject(dto.getSubject())
				.content(dto.getContent()).writer(dto.getWriter()).files(files)
				.build();
		repository.save(entity);
		return "multifile/list";
	}

	private List<MultiFileEntity> fileUpload(List<MultipartFile> files) {
		List<MultiFileEntity> result=null;
		System.out.println("파일존재여부"+files.isEmpty());
		if(files.isEmpty()) {
			
			result=new Vector<>();
		for(MultipartFile mf : files) {
			
			long fileSize=mf.getSize();
			String fileOrgName=mf.getOriginalFilename();
			String[] strs=fileOrgName.split("[.]");
			
			String fileNewName=strs[0]+"_"+(System.nanoTime()/1000000)+"."+strs[1];
			System.out.println("fileNewName"+fileNewName);
			
			
			//System.out.println("current"+current);
			//System.out.println("format적용"+current.format(formatter));
			
			String filePath="/upload/";//+current.format(formatter)+"/";
			
			MultiFileEntity entity=MultiFileEntity.builder()
					.fileSize(fileSize).fileOrgName(fileOrgName).fileNewName(fileNewName).filePath(filePath)
					.build();
			result.add(entity);
			
			ClassPathResource cpr =new ClassPathResource("static"+filePath);
		
			try {
				File location=cpr.getFile(); //존재하지않으면 디렉토리 생성
				mf.transferTo(new File(location,fileNewName));
				System.out.println("파일업로드완료");
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			
		}//for end
		}
		return result;
	}
	
	
}
