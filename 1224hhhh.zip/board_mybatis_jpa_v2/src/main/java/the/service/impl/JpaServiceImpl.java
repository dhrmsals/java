package the.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import the.domain.dto.PageInfo;
import the.domain.dto.jpaboard.BoardListDto;
import the.domain.entity.Board;
import the.domain.entity.BoardRepository;
import the.service.JpaService;

@Log4j2
@RequiredArgsConstructor
@Service
public class JpaServiceImpl implements JpaService {

	private final BoardRepository boardRepository;
	
	@Override
	public String getList(Model model, int page) {
		if(page<1)page=1;
		int size=10;
		Pageable pageable=PageRequest.of(page-1, size,Direction.DESC,"no");
		
		Page<BoardListDto> result=boardRepository.findAll(pageable)
									.map( entity->new BoardListDto(entity) );
		model.addAttribute("list", result.getContent());//List<BoardListDto>
		
		PageInfo pd=new PageInfo(result.getTotalPages(), page, 10);
		model.addAttribute("pd", pd);
		log.debug("로그기록");
		
		/*
		Page<Board> result=boardRepository.findAll(pageable);
		//Board -> BoardListDto 필요한 컬럼들을 매핑
		List<BoardListDto> boardlist=result.getContent().stream()
				//.map( entity->new BoardListDto(entity) )
				.map(BoardListDto::new)
				.collect(Collectors.toList());		
		model.addAttribute("list", boardlist);
		*/
		return "jpaboard/list";
	}

	

}
