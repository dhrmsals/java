package the.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.multipart.MultipartFile;

import the.domain.dto.multifile.MultiFileBoardDto;
import the.service.MultiFileBoardService;
import the.service.impl.MultiFileBoardServiceImpl;

@Controller
public class MultiFileBoardController {

	@Autowired
	MultiFileBoardService service;
	
	@GetMapping("/multifiles")
	public String list() {
		return "multifile/list";
		
	}
	@GetMapping("/multifiles/write")
	public String writepage() {
		return "multifile/write";
		
	}
	
	@PostMapping("/multifiles")
	public String save(MultiFileBoardDto dto) {
		
		
		return service.fileUploadAndSave(dto);
		
	}
	
}
