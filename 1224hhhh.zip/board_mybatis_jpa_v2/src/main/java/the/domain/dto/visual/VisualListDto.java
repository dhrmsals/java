package the.domain.dto.visual;

import lombok.Data;
import the.domain.entity.Visual;

@Data
public class VisualListDto {
	private long vno;
	private String title;
	private String sub;
	
	public VisualListDto(Visual entity) {
		this.vno = entity.getVno();
		this.title = entity.getTitle();
		this.sub = entity.getSub();
	}
	
	
}
