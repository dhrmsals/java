package the.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@SequenceGenerator(name = "gen_seq_vis",
		sequenceName = "seq_vis", initialValue = 1, allocationSize = 1)
@Entity
public class Visual {
	
	@Id
	@GeneratedValue(generator = "gen_seq_vis", strategy = GenerationType.SEQUENCE)
	private long vno;
	
	@Column(nullable = false)
	private String title;
	@Column(nullable = false)
	private String sub;
	
}
