package the.domain.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@SequenceGenerator(name = "gen_seq_visf",
	sequenceName = "seq_visf", initialValue = 1, allocationSize = 1)
@Entity
public class VisualFile {

	@Id
	@GeneratedValue(generator = "gen_seq_visf", strategy = GenerationType.SEQUENCE)
	private long fno;
	
	@Column(nullable = false)
	private String filePath;
	@Column(nullable = false)
	private String fileName;
	@Column(nullable = false)
	private long fileSize;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Visual visual;
}
