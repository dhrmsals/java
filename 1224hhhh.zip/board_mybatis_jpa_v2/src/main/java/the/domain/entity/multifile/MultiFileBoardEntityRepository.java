package the.domain.entity.multifile;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository //dao역할                 								//참고할테이블이름			//pk값	
public interface MultiFileBoardEntityRepository  extends JpaRepository<MultiFileBoardEntity, Long>{
	//사용자가만들 쿼리영역
}
