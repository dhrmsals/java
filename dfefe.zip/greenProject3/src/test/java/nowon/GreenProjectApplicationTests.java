package nowon;

import java.util.stream.IntStream;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.annotation.Commit;

import lombok.extern.log4j.Log4j2;
import nowon.domain.entity.BoardEntity;
import nowon.domain.entity.BoardEntityRepository;
import nowon.domain.entity.MemberEntity;
import nowon.domain.entity.MemberEntityRepository;
import nowon.security.MemberRole;

@Log4j2
@SpringBootTest
class GreenProjectApplicationTests {

	@Autowired
	MemberEntityRepository memberEntityRepository;
	@Autowired
	PasswordEncoder passwordEncoder;
	@Autowired
	BoardEntityRepository boardEntityRepository;
	
	//@Test
	void 더미데이터입력테스트() {
		IntStream.rangeClosed(1, 10).forEach(i->{
			MemberEntity memberEntity=MemberEntity.builder()
					.email("test"+i+"@test.com")
					.password(passwordEncoder.encode("1111"))
					.name("test"+i)
					.build();
			memberEntity.addRole(MemberRole.USER);
			memberEntityRepository.save(memberEntity);
			
			
		});
		
	}
	
	//@Test
	void board입력테스트() {
		
		BoardEntity entity=BoardEntity.builder()
				.subject("제목 테스트 ")
				.content("내용 테스트 ")
				.writer("작성자")
				.build();
		BoardEntity result=boardEntityRepository.save(entity);
		if(result!=null) {
			log.info("게시글 입력성공! : "+ result);
		}
		
	}
	
	//@Test
	void board모두읽어오기테스트() {
		boardEntityRepository.findAll().forEach(entity->{
			log.info("baord의 데이터 : "+ entity);
		});
	}
	
	//@Transactional
	//@Commit
	//@Test
	/*
	 * void board수정테스트() { //11번 수정예시 BoardEntity
	 * result=boardEntityRepository.findById(11L)
	 * .map(e->e.update("제목수정","내용수정")).orElse(null);
	 * 
	 * if(result!=null) { log.info("수정된 정보 :"+ result); } }
	 */
	//@Test
	void board삭제() {
		//11번삭제
		long bno=11;
		boardEntityRepository.deleteById(bno);
		log.info(bno +"번 데이터 삭제완료!");
	}
	

}
