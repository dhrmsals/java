package nowon.security;

import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.oauth2.client.CommonOAuth2Provider;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

import nowon.domain.entity.MemberEntity;
import nowon.domain.entity.MemberEntityRepository;

@Service
public class CustomUserOAuth2UserService extends DefaultOAuth2UserService{
	@Autowired
	private PasswordEncoder passwordEncoder;
	@Autowired
	private MemberEntityRepository memberEntityRepository;
	
	@Override
	public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {
		OAuth2User oAuth2User=super.loadUser(userRequest);
		//소셜로그인 인증완료
		
		String registrationId=userRequest.getClientRegistration().getRegistrationId();
		System.out.println(registrationId);
		
		/*
		 * Map<String, Object> map=oAuth2User.getAttributes(); //return
		 * saveSocailUser(registrationId,oAuth2User); for(String key:map.keySet()) {
		 * System.out.println(":"+map.get(key)); }
		 */
		return saveSocailUser(registrationId, oAuth2User);
	}
	
	
	private OAuth2User saveSocailUser(String registrationId, OAuth2User oAuth2User) {
		String email=null;
		String name=null;
		if(registrationId.equals("google")) {
			email=oAuth2User.getAttribute("email");
			name=oAuth2User.getAttribute("name");
		}else if (registrationId.equals("naver")) {
			
			//회원정보가 json data 로제공하는데 response라는 name에서 제공하고있다.
			Map<String, Object> result= oAuth2User.getAttribute("response");
			
			  for(String key : result.keySet()) {
			  System.out.println(key+":"+result.get(key)); }
			 
			email=(String)result.get("email");
			name=(String)result.get("name");
			
		}
		//가입여부 췍
		Optional<MyUserDetails> check=memberEntityRepository.findById(email)
				.map(MyUserDetails::new);
		if(check.isPresent()) {
			return check.get();
		}
		
		//소셜정보 회원가입처리 
		MemberEntity entity=MemberEntity.builder()
				.email(email).name(name).isSocail(true)
				.password(passwordEncoder.encode("socailuser"+System.currentTimeMillis()))
				.build();
		entity.addRole(MemberRole.USER);
		MemberEntity result=memberEntityRepository.save(entity);
		MyUserDetails myUserDetails=new MyUserDetails(result); 
		
		
		return myUserDetails;
	}


}
