package nowon.domain.entity;

import java.util.List;
import java.util.Vector;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import nowon.domain.dto.BoardUpdateDto;

@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Table(name = "mar_board")
@Entity//DB 와 매핑되는 클래스
public class BoardEntity extends BaseEntity{// Repository 접근가능

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long bno;
	@Column(nullable = false)
	private String subject;
	@Column(nullable = false)
	private String content;
	@Column(nullable = false)
	private String writer;
	private int readCount;
	//조회수 관련메서드
	public BoardEntity updateReadCount() {
		readCount++;
		return this;
		
	}
	//제목 내용 업데이트
	public BoardEntity newupdate(BoardUpdateDto dto) {
		this.subject=dto.getSubject();
		this.content=dto.getContent();
		return this;
	}
	
	@Builder.Default
	@OneToMany(mappedBy = "board",cascade = CascadeType.ALL)
	List<ReplyEntity> replies=new Vector<ReplyEntity>();
	
	
}
