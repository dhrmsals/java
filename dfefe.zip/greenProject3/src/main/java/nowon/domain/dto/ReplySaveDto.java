package nowon.domain.dto;

import lombok.Data;
import nowon.domain.entity.BoardEntity;
import nowon.domain.entity.ReplyEntity;

@Data
public class ReplySaveDto {
	private String reply;
	private String replyer;
	
	public ReplyEntity toEntity(long bno) {
		return ReplyEntity.builder().reply(reply).replyer(replyer).board(BoardEntity.builder().bno(bno).build())
				.build();
		
	}
	
}
