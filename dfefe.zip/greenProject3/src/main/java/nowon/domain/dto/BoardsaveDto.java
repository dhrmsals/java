package nowon.domain.dto;

import lombok.Setter;
import lombok.ToString;
import nowon.domain.entity.BoardEntity;

@ToString
@Setter
public class BoardsaveDto {
	private String subject;
	private String content;
	private String writer;
	
	public BoardEntity toEntity() {
		return BoardEntity.builder()
				.subject(subject).content(content).writer(writer)
				.build();
		
	}

}
