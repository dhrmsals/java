package nowon.domain.dto;

import lombok.Setter;
import lombok.ToString;
import nowon.domain.entity.ABoardEntity;
import nowon.domain.entity.BoardEntity;

@ToString
@Setter
public class ABoardsaveDto {
	private String subject;
	private String content;
	private String writer;
	
	public ABoardEntity toEntity() {
		return ABoardEntity.builder()
				.subject(subject).content(content).writer(writer)
				.build();
		
	}

}
