package nowon.domain.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import nowon.domain.entity.MemberEntity;

@Data
public class MemberSave {
	private String email;
	private String password;
	private String name;

	
	public MemberEntity toEntity() {
		return MemberEntity.builder().email(email).password(password).name(name).build();
		
	}
	
}
