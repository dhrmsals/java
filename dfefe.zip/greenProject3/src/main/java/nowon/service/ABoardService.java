package nowon.service;

import org.springframework.ui.Model;

import nowon.domain.dto.ABoardsaveDto;

public interface ABoardService {

	String detailAndReadCount(long pno, Model model);

	String sava(ABoardsaveDto saveDto);

	String list3(Model model);

}
