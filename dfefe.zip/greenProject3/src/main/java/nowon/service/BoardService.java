package nowon.service;

import org.springframework.ui.Model;

import nowon.domain.dto.ABoardsaveDto;
import nowon.domain.dto.BoardUpdateDto;
import nowon.domain.dto.BoardsaveDto;
import nowon.domain.dto.ReplySaveDto;

public interface BoardService {

	String seva(BoardsaveDto saveDto);

	String detailAndReadCount(long bno, Model model);

	String list(Model model);

	void deletebyID(long bno);

	String update(long bno, BoardUpdateDto dto);

	String listPage(int page, Model model);

	String getReplies(long bno, Model model);

	void saveReplies(long bno, ReplySaveDto dto);

	

}
