package nowon.service;

import nowon.domain.dto.MemberSave;

public interface MemberService {

	void save(MemberSave dto);

}
