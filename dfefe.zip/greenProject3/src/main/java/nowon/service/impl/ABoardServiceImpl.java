package nowon.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import nowon.domain.dto.ABoardDetailDto;
import nowon.domain.dto.ABoardListDto;
import nowon.domain.dto.ABoardsaveDto;
import nowon.domain.dto.BoardDetailDto;
import nowon.domain.dto.BoardListDto;
import nowon.domain.entity.ABoardEntityRepository;
import nowon.service.ABoardService;

@Service
public class ABoardServiceImpl implements ABoardService {
	
	@Autowired
	ABoardEntityRepository repository;
	
	@Transactional
	@Override
	public String detailAndReadCount(long pno, Model model) {
		ABoardDetailDto dto=repository.findById(pno)
				.map(e->e.updateReadCount())
				.map(ABoardDetailDto::new)
				.orElseThrow();
		model.addAttribute("detail",dto);
		
		return "menu/detail";
	}

	@Override
	public String sava(ABoardsaveDto saveDto) {
		repository.save(saveDto.toEntity());
		return "menu/list";
	}

	@Override
	public String list3(Model model) {
		Sort sort=Sort.by(Direction.DESC, "pno");// order by no desc
		List<ABoardListDto> list=repository.findAll(sort).stream() //list콜렉션에서 entity객체를 하나씩..
											//.map((e)-> new BoardListDto(e) )
											.map(ABoardListDto::new) //entity->BoardListDto로 데이터변경
											.collect(Collectors.toList());// dto를 list로 add
		System.out.println(list);
		model.addAttribute("list", list);
		return "menu/list"; //board/list.html
	}

}
