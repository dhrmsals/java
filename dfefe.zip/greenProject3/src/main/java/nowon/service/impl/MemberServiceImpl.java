package nowon.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import nowon.domain.dto.MemberSave;
import nowon.domain.entity.MemberEntity;
import nowon.domain.entity.MemberEntityRepository;
import nowon.security.MemberRole;
import nowon.service.MemberService;

@Service
public class MemberServiceImpl implements MemberService {
	
	@Autowired
	MemberEntityRepository repository;
	@Autowired
	PasswordEncoder passwordEncoder;
	@Override
	public void save(MemberSave dto) {
		MemberEntity entity=MemberEntity.builder()
				.email(dto.getEmail())
				.password(passwordEncoder.encode(dto.getPassword()))
				.name(dto.getName())
				.build();
				entity.addRole(MemberRole.USER);
				repository.save(entity);
	}

}
