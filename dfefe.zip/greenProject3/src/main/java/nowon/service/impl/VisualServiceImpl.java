package nowon.service.impl;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import nowon.domain.dto.visual.SaveDto;
import nowon.domain.dto.visual.VisualListDto;
import nowon.domain.entity.Visual;
import nowon.domain.entity.VisualRepository;
import nowon.service.VisualService;

@RequiredArgsConstructor
@Log4j2
@Service
public class VisualServiceImpl implements VisualService {
	
	private final VisualRepository visualRepository;
	
	@Override
	public void saveAndFileUpload(MultipartFile visualFile, SaveDto dto) throws IOException {
		// TODO Auto-generated method stub
		long fileSize=visualFile.getSize();
		String fileName=visualFile.getOriginalFilename();
		/*
		String filePath="/images/visual/";
		ClassPathResource cpr=new ClassPathResource("static"+filePath);
		File location=cpr.getFile();
		visualFile.transferTo(new File(location, fileName));
		*/

		//리눅스 물리경로에 업로드하는방법
		String location="/home/ec2-user/src/root";//톰캣설정한 root
		String filePath="/file/visual/";// /home/ec2-user/src/root
		visualFile.transferTo(new File(location+filePath, fileName));
		log.debug("파일업로드 완료!");
		int size=visualRepository.findAll().size();
		Visual entity=Visual.builder()
				.fileSize(fileSize).filePath(filePath).fileName(fileName)
				.title(dto.getTitle()).subTitle(dto.getSubTitle()).orderNo(size+1)
				.build();
		
		visualRepository.save(entity);
		
		
		
		
	}

	@Override
	public String getlist(Model model) {
		model.addAttribute("list", visualRepository.findAll().stream()
												.map(VisualListDto::new)
												.collect(Collectors.toList()));
		/*
		List<Visual> result2=visualRepository.findAll();
		List<VisualListDto> list2=new Vector<>();
		for(Visual entity:result2) {
			VisualListDto dto=new VisualListDto(entity);
			list2.add(dto);
		}
		model.addAttribute("list2", list2);
		*/
		return "admin/visual/list";
	}

	@Override
	public String getPageList(Model model) {
		model.addAttribute("list", visualRepository.findAll().stream()
				.map(VisualListDto::new)
				.collect(Collectors.toList()));
		return "admin/visual/page-list";
	}

}
