package nowon.service.impl;

import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import nowon.domain.dto.BoardDetailDto;
import nowon.domain.dto.BoardsaveDto;
import nowon.domain.dto.ReplySaveDto;
import nowon.domain.entity.BoardEntityRepository;
import nowon.domain.entity.ReplyEntity;
import nowon.domain.entity.ReplyEntityRepository;
import nowon.service.BoardService;
import nowon.domain.dto.BoardListDto;
import nowon.domain.dto.BoardUpdateDto;
import nowon.domain.entity.BoardEntity;

@Service
public class BoardServiceImpl implements BoardService {
	
	@Autowired
	BoardEntityRepository repository;
	@Autowired
	ReplyEntityRepository replyEntityRepository;
	
	
	@Override
	public String seva(BoardsaveDto saveDto) {
		repository.save(saveDto.toEntity());
		return "redirect:/board";
	}

	@Transactional
	@Override
	public String detailAndReadCount(long bno, Model model) {
		BoardDetailDto dto=repository.findById(bno)
				.map(e->e.updateReadCount())
				.map(BoardDetailDto::new)
				.orElseThrow();
		model.addAttribute("detail",dto);
		
		return "board/detail";
	}

	@Override
	public String list(Model model) {
		Sort sort=Sort.by(Direction.DESC, "bno");// order by no desc
		List<BoardListDto> list=repository.findAll(sort).stream() //list콜렉션에서 entity객체를 하나씩..
											//.map((e)-> new BoardListDto(e) )
											.map(BoardListDto::new) //entity->BoardListDto로 데이터변경
											.collect(Collectors.toList());// dto를 list로 add
		model.addAttribute("list", list);
		return "board/list"; //board/list.html
	}

	@Override
	public void deletebyID(long bno) {
		repository.deleteById(bno);
		
	}
	@Transactional
	@Override
	public String update(long bno, BoardUpdateDto dto) {
		repository.findById(bno).
		map(e->e.newupdate(dto));
		
		
		return "redirect:/board/"+bno; 
		
	}

	@Override
	public String listPage(int page, Model model) {
		int size=10;
		//오름차순정렬
		Sort sort=Sort.by(Direction.DESC,"bno");
		//페이지 관련 호출명
		Pageable pageable=PageRequest.of(page-1, size, sort);
		Page<BoardEntity> result=repository.findAll(pageable);
		int pageTot=result.getTotalPages();
		
		//페이지개수 및 페이지그룹설정
		int pageGroup=5;
		int pageGroupNo= page / pageGroup;
		if(page % pageGroup > 0) pageGroupNo++;
		
		int to = pageGroupNo * pageGroup;
		int from = to - pageGroup +1;
		if(to > pageTot) to = pageTot;
		
		model.addAttribute("pages",IntStream.rangeClosed(to, from).toArray());
		model.addAttribute("to", to);
		model.addAttribute("from", from);
		model.addAttribute("pageTot", pageTot);
		
		List<BoardListDto> dto=result.getContent().stream()
				.map(BoardListDto::new)
				.collect(Collectors.toList());
		model.addAttribute("list",dto);
		return "board/list";
	}
	/////////댓글영역////////////////////
	@Override
	public String getReplies(long bno, Model model) {
		/* Sort sort=Sort.by(Direction.DESC,"rno"); */
		
		Pageable pageable=PageRequest.of(0, 3,Direction.DESC,"rno");
		List<ReplyEntity> list=replyEntityRepository.findAllByBoard_bno(bno, pageable);
		model.addAttribute("rlist",list);
		
		return "/board/replyes";
	}

	@Override
	public void saveReplies(long bno, ReplySaveDto dto) {
		replyEntityRepository.save(dto.toEntity(bno));
		
	}
	
		
	}


