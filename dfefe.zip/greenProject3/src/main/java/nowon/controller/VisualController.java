package nowon.controller;

import java.io.IOException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.multipart.MultipartFile;

import lombok.RequiredArgsConstructor;
import nowon.domain.dto.visual.SaveDto;
import nowon.service.VisualService;

@RequiredArgsConstructor
@Controller
public class VisualController {
	
	private final VisualService service;
	
	@GetMapping("/visuals")
	public String visualList(Model model) {
		return service.getPageList(model);
	}
	
	@GetMapping("/admin/visualpage")
	public String visualpage() {
		return "admin/visual/write";
	}
	
	
	//이미지 등록
	@PostMapping("/admin/visuals")
	public String Save(MultipartFile visualFile, SaveDto dto) throws IOException{
		service.saveAndFileUpload(visualFile, dto);
		return "redirect:/admin/visuals";
	}
	//이미지 리스트
	@GetMapping("/admin/visuals")
	public String list(Model model) {
		return service.getlist(model);
	}
}
