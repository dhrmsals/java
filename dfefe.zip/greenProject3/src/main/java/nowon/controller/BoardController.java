package nowon.controller;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.extern.log4j.Log4j2;
import nowon.domain.dto.ABoardsaveDto;
import nowon.domain.dto.BoardUpdateDto;
import nowon.domain.dto.BoardsaveDto;
import nowon.domain.dto.ReplySaveDto;
import nowon.service.ABoardService;
import nowon.service.BoardService;
import nowon.service.impl.ABoardServiceImpl;
import nowon.service.impl.BoardServiceImpl;



@Log4j2
@Controller
public class BoardController {
	@Autowired
	private BoardService service;
	@Autowired
	private ABoardService aservice;
	
	@GetMapping("/boards")
	public String list(@RequestParam(defaultValue = "1")int page,Model model) {
		
		
		return service.listPage(page,model);
		
	}
	
	//게시글 목록
	@GetMapping("/board/{bno}")
	public String list(@PathVariable long bno, Model model) {
		return service.detailAndReadCount(bno,model);
	}
	
	
	//게시글 작성화면
	@GetMapping("/boards/write")
	public String writePage() {
		log.debug("writePage() 실행!");
		return "board/write";
	}
	
	//게시글작성
	
	@PostMapping("/board")
	public String save(BoardsaveDto saveDto) {
		return service.seva(saveDto);
	}
	
	@PutMapping("/board/{bno}")
	public String update(@PathVariable long bno,BoardUpdateDto dto) {
		
		return service.update(bno,dto);

		
		
	}
	
	//게시판삭제
	@DeleteMapping("/board/{bno}")
	public String deleteBoard(@PathVariable long bno) {
		service.deletebyID(bno);
		return "redirect:/board";
	}
	@GetMapping("/board")
	public String listPage(@RequestParam(defaultValue = "1")int page, Model model) {
		
		return service.listPage(page, model);
	}
	
	//////////////////////////////댓글영역//////////////////
	
	
	@GetMapping("/boards/{bno}/replies")
	public String getReplies(@PathVariable long bno,Model model){
		return service.getReplies(bno,model);
		
	}
	@ResponseBody
	@PostMapping("/boards/{bno}/replies")
	public void reply(@PathVariable long bno,ReplySaveDto dto) {
		service.saveReplies(bno,dto);
	}
	
	//adminbard////
	
	
	@GetMapping("/aboard/{pno}")
	public String list1(@PathVariable long pno, Model model) {
		return aservice.detailAndReadCount(pno,model);
	}
	
	@GetMapping("/aboards/write")
	public String aboards_write() {
		return "menu/write";
	}
	
	@PostMapping("/aboards/write")
	public String save(ABoardsaveDto saveDto) {
		return aservice.sava(saveDto);
	}
	
	@GetMapping("/aboards")
	public String listPage(Model model) {
		
		return aservice.list3(model);
	}
	
	
}
