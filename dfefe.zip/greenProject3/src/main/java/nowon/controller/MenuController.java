package nowon.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class MenuController {
	
	@GetMapping("/menus")
	public String adminPage() {
		return "/menu/menu1";
	}
	
	@GetMapping("/menus1")
	public String admin() {
		return "/menu/menu2";
	}
	
	@GetMapping("/menus2")
	public String adminboard() {
		return "/menu/list";
	}
	
}
