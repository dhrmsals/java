package nowon.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import nowon.domain.dto.MemberSave;
import nowon.service.MemberService;

@Controller
public class LogController {
	
	@Autowired
	MemberService service;
	
	@GetMapping("/log/page")
	public String loginPage() {
		System.out.println("로그인 페이지이동");
		return "log/login";
	}
	
	
	
	@GetMapping("/log/signup")
	public String pass() {
		System.out.println("회원가입 페이지이동");
		return "log/signup";
		
	}
	@PostMapping("/mem/reg")
	public String regPage(MemberSave dto) {
		service.save(dto);
		return "redirect:/log/page";
		
	}
	
	
}
