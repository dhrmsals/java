/**
 * 
 */

jQuery(document).ready(function(){
	jQuery('.slide_sub1').skdslider({delay:2000, animationSpeed: 500,showNextPrev:false,showPlayButton:true,autoSlide:true,animationType:'sliding'});
	
	jQuery('#responsive').change(function(){
	  $('#responsive_wrapper').width(jQuery(this).val());
	  $(window).trigger('resize');
	});
	
});