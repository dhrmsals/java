// JavaScript Document

$(document).ready(function(){
	$('ul.sub_nav').slideUp(0);
	
	$('div.nav_bg').slideUp(0);
	$('div.nav_bg').appendTo('header');
	
	$('div.h_bottom').hover(function(){
		$('div.nav_bg').slideDown('fast',function(){$(this).stop();});
		$('ul.sub_nav').slideDown('fast',function(){$(this).stop();});
		
	},function(){
		$('div.nav_bg').slideUp('fast',function(){$(this).stop();});
		$('ul.sub_nav').slideUp('fast',function(){$(this).stop();});
	});
	
	
	//웹접근성용 제이쿼리
	$('div.h_bottom > ul > li > a').focus(function() {
		$('div.nav_bg').slideDown('fast',function(){$(this).stop();});
		$('ul.sub_nav').slideDown('fast',function(){$(this).stop();});
		
    });
	$('div.h_bottom > ul > li:last > ul.sub_nav > li:last > a').blur(function() {
		$('div.nav_bg').slideUp('fast',function(){$(this).stop();});
		$('ul.sub_nav').slideUp('fast',function(){$(this).stop();});
    });
	
	//하위메뉴 오버시 메인메뉴 색변경
	
});