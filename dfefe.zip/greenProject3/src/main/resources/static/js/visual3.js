//하단메뉴 함수

//디스플레이 나타내는 함수
$(document).ready(function(){
	$('div.box1_top > div:first > h2').addClass('on');
	$('div.box1_bottom > div:first').css('display','block');
//하단탑메뉴 클릭시 나타내는함수	
$('div.box1_top > div').click(function(){
	$('div.box1_top > div > h2').removeClass('on');
	$(this).find('>h2').addClass('on');
	
	i = $(this).index();
	$('div.box1_bottom > div').css('display', 'none');
		$('div.box1_bottom > div').eq(i).fadeIn('fast'); 

});

//하단슬라이드
	$('div.box_button > ul > li:first > a').addClass('on');
	$('div.box4_bottom > ul > li:first').css('display','block');
	
	$('div.box_button > ul > li').click(function() {
        $('div.box_button > ul > li > a').removeClass('on');
		$(this).find('>a').addClass('on');
		
		i = $(this).index();
		
		$('div.box4_bottom > ul > li').css('display', 'none');
		$('div.box4_bottom > ul > li').eq(i).fadeIn('fast'); 
    });
	$('div.srm_section > div:first > ul > li').click(function() {
        $('div.srm_section > div:first > ul > li').removeClass('on');
		$(this).addClass('on');
		
		i = $(this).index();
		
		$('div.down_box_all > div').css('display', 'none');
		$('div.down_box_all > div').eq(i).fadeIn('fast');
    });
	
	$('div.btn_box01 > div').click(function() {
        $('div.btn_box01 > div').removeClass('on');
		$(this).addClass('on');
		
		i = $(this).index();
		
		$('div.content_box01 > div').css('display', 'none');
		$('div.content_box01 > div').eq(i).fadeIn('fast');
		
    });
	

});

