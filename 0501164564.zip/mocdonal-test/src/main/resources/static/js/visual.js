/**
 * 작성자 : 오근민
 */
var imgurls =[
	"/"

];

var myTimeout;
var speed=400;
var imgSize=1920;
var delay=3000;

$(function(){
	myTimeout = setTimeout(move, delay);
});

function move(){
	var imgs=$("#visual>.visual-area .images");
	
	var first_li=$("#visual>.visual-area .images li:first-child");
	var last_li=$("#visual>.visual-area .images li:last-child");
	
	imgs.animate({marginLeft: -imgSize},speed,function(){
		//이미지가 이동한다음 실행
		//첫번째 이미지를 맨뒤로..,,, margin-left :0;
		last_li.after(first_li);
		imgs.css("margin-left", 0);
		
		myTimeout = setTimeout(move, delay);
	});
}