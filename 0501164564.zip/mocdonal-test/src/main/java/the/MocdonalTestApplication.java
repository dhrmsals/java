package the;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MocdonalTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(MocdonalTestApplication.class, args);
	}

}
